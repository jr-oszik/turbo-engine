fx_version 'cerulean'
game { 'gta5' }

description 'qb-meth'
version '1.0.0'

client_script "client.lua"
server_script "server.lua"

lua54 'yes'