fx_version 'cerulean'
games { 'gta5' }

author 'Nick Perry'
description 'Admin Zone'
version '1.0.4'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'
