import { Server } from 'qbcore.js';

export const QBCore: Server = global.exports['qb-core'].GetCoreObject();
