import { Client } from 'qbcore.js';

export const QBCore: Client = global.exports['qb-core'].GetCoreObject();
